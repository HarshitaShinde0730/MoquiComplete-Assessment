package example.service

import org.moqui.context.ExecutionContext

class GetFemalePersonsService {

    static void getFemalePersons(ExecutionContext ec) {
        def personList = ec.entity.find("example.Person")
                .condition("gender = 'F'")
                .list()
        ec.service.out("personsList", personList)
    }
}